To run:

`python3 LR0Items.py < input.txt`

where "input.txt" is an input file in the current directory.